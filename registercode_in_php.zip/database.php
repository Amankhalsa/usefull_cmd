<?php
	$servername = "localhost";
	$username = "webbeingdigital_register";
	$password = "Root@77625";
	$db="webbeingdigital_register";
	/*Create connection*/
	$conn = mysqli_connect($servername, $username, $password,$db);
?>