<?php
session_start();
unset($_SESSION["email"]);
unset($_SESSION["password"]);
header("Location:https://www.webbeingdigital.com/register/");


session_start(); //to ensure you are using same session
session_destroy(); //destroy the session
?>